import pygame
import random
import time
from pygame.locals import *   # needed for KEYDOWN, K_ESCAPE, etc

# Setup pygame
mainClock = pygame.time.Clock()
fps = 37

pygame.init()
pygame.display.set_caption('Asteroid Evaders')
screen_width, screen_height = 750,750
screen = pygame.display.set_mode((screen_width, screen_height), 0, 32)  #based on game window size
# set_mode(size=(0, 0), flags=0, depth=0, display=0, vsync=0) -> Surface
# Initialize a window or screen for display

font = pygame.font.SysFont('Times New Roman', 50, bold = True)   # function - pygame module for loading and rendering fonts
# pygame.font.SysFont(name, size, bold = False, italic = False, constructor = None)


def draw_text(text, font, color, surface, x, y):
    text_obj = font.render(text, 1, color)  #Create a surface object in which Text is drawn on it, using render() method
    text_rect = text_obj.get_rect()  #Create a rectangular object for the text surface object using get_rect() method
    text_rect.midtop = (screen_width/2, 20)
    surface.blit(text_obj, text_rect)


white = (255, 255, 255)
black = (0, 0, 0)
smallfont = pygame.font.SysFont('Leelawadee UI Semilight', 35)
textfont = pygame.font.SysFont('Microsoft New Tai Lue', 28)
menufont = pygame.font.SysFont('Microsoft New Tai Lue', 55)
score_text = pygame.font.SysFont('Microsoft New Tai Lue', 40)

menu_bg = pygame.image.load("Images/MenuBackground.png")
menu_bg = pygame.transform.scale(menu_bg,(screen_width,screen_height))

score = 0


def Titlescreen():
    text_0 = menufont.render('ASTEROID EVADERS', True, black)
    text_1 = menufont.render('ASTEROID EVADERS', True, white)
    text_2 = smallfont.render('Continue', True, white)

    running = True

    screen.blit(menu_bg, (0, 0))
    button1 = pygame.Rect(290, 375, 200, 50)  # pygame.Rect (x_pos, y_pos, width, height)
    pygame.draw.rect(screen, (75, 75, 75), button1)

    screen.blit(text_0, (145, 307))
    screen.blit(text_1, (149, 307))
    screen.blit(text_2, (320, 375))

    while running:

        for event in pygame.event.get():
            if event.type == QUIT:
                exit_all()

            if event.type == KEYDOWN:
                running = False

            if event.type == MOUSEBUTTONDOWN:
                mouse_x, mouse_y = pygame.mouse.get_pos()
                if button1.collidepoint((mouse_x, mouse_y)):
                    running = False

        pygame.display.update()
        mainClock.tick(fps)


def main_menu():
    text1 = smallfont.render('Start Game', True, white)
    text2 = smallfont.render('Instructions', True, white)
    text3 = smallfont.render('Extra Info', True, white)
    text4 = smallfont.render('Credits', True, white)
    text5 = smallfont.render('Exit', True, white)

    clicked = 0
    menu_run = True

    screen.fill((0, 0, 0))
    screen.blit(menu_bg,(0,0))
    draw_text('Asteroid Evaders', font, (255, 255, 255), screen, 20, 20)

    button_1 = pygame.Rect(275, 100, 200, 50)   #pygame.Rect (x_pos, y_pos, width, height)
    button_2 = pygame.Rect(275, 200, 200, 50)
    button_3 = pygame.Rect(275, 300, 200, 50)
    button_4 = pygame.Rect(275, 400, 200, 50)
    button_5 = pygame.Rect(275, 500, 200, 50)

    pygame.draw.rect(screen, (0, 0, 0), button_1)
    pygame.draw.rect(screen, (0, 0, 0), button_2)
    pygame.draw.rect(screen, (0, 0, 0), button_3)
    pygame.draw.rect(screen, (0, 0, 0), button_4)
    pygame.draw.rect(screen, (0, 0, 0), button_5)

    screen.blit(text1, (295, 100))
    screen.blit(text2, (290, 200))
    screen.blit(text3, (300, 300))
    screen.blit(text4, (325, 400))
    screen.blit(text5, (345, 500))

    while menu_run:

        for event in pygame.event.get():
            if event.type == QUIT:
                menu_run = False

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    menu_run = False

            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    mouse_x, mouse_y = pygame.mouse.get_pos()

                    if button_1.collidepoint((mouse_x, mouse_y)):
                        clicked = 1
                    elif button_2.collidepoint((mouse_x, mouse_y)):
                        clicked = 2
                    elif button_3.collidepoint((mouse_x, mouse_y)):
                        clicked = 3
                    elif button_4.collidepoint((mouse_x, mouse_y)):
                        clicked = 4
                    elif button_5.collidepoint((mouse_x, mouse_y)):
                        clicked = 5

                if clicked > 0:
                    menu_run = False

        pygame.display.update()
        mainClock.tick(fps)

    return clicked


def game():
    # Object class
    class Rocket(pygame.sprite.Sprite):
        def __init__(self, img):  # self refers to the object instance
            super().__init__()

            self.image = img
            self.rect = self.image.get_rect()

        def set_position(self, x, y):
            self.rect.x = x
            self.rect.y = y

        def get_y(self):
            return self.rect.y


        def get_height(self):
            return self.rect.height

        def get_width(self):
            return self.rect.width

    class Asteroid(pygame.sprite.Sprite):
        # asteroids
        def __init__(self, image, speed):
            super().__init__()

            self.image = image
            self.rect = self.image.get_rect()
            self.speed = speed
            self.rect.x = 750
            self.rect.y = random.randint(0, 660)

        def set_position(self, x, y):
            self.rect.x = x
            self.rect.y = y

        def set_speed(self, speed):
            self.speed = speed

        def get_speed(self):
            return self.speed

        def update(self, *args, **kwargs):
            global score
            if self.rect.x > (-self.rect.width * 2):
                self.rect.x -= self.speed
            else:
                score += 1
                self.rect.x = 750
                self.rect.y = random.randint(0, 660)

    global fps
    lives = 5
    global score
    score = 0
    tscore = 0
    # manages how fast screen refreshes
    clock = pygame.time.Clock()

    # bg
    bg = pygame.image.load("Images/Space_Backround.png.jpg")
    bg = pygame.transform.scale(bg, (screen_width, screen_height))

    i = 0

    # rocket
    img = pygame.image.load("Images/Red_Spaceship.png (2).png")
    img = pygame.transform.scale(img, (60, 130))
    img = pygame.transform.rotate(img, 270)

    vel = 7
    x_pos = 40
    y_pos = 100

    # asteroids
    ast_img_slow1 = pygame.image.load("Images/Asteroid_Slow.png.png")
    ast_img_slow1 = pygame.transform.scale(ast_img_slow1, (50, 70))
    ast_img_slow2 = ast_img_slow1
    ast_slow_x_pos = 750
    ast_img_fast1 = pygame.image.load("Images/Asteroid_Fast.png(3).png")
    ast_img_fast1 = pygame.transform.rotate(ast_img_fast1, 270)
    ast_img_fast2 = ast_img_fast1
    ast_img_fast3 = ast_img_fast1

    all_sprites = pygame.sprite.Group()
    rocket = Rocket(img)

    slow_asteroid1 = Asteroid(ast_img_slow1, 8)
    slow_asteroid2 = Asteroid(ast_img_slow2, 9)
    fast_asteroid1 = Asteroid(ast_img_fast1, 12)
    fast_asteroid2 = Asteroid(ast_img_fast1, 15)
    fast_asteroid3 = Asteroid(ast_img_fast1, 18)
    asteroids = pygame.sprite.Group()
    asteroids.add(slow_asteroid1)
    asteroids.add(slow_asteroid2)
    asteroids.add(fast_asteroid1)
    asteroids.add(fast_asteroid2)
    asteroids.add(fast_asteroid3)

    all_sprites.add(rocket)
    all_sprites.add(asteroids.sprites())

    # sound effects
    movingSound = pygame.mixer.Sound("Audio/move.mp3")
    hitSound = pygame.mixer.Sound("Audio/hit1.wav")
    gameOver = pygame.mixer.Sound("Audio/gameOver.wav")


    run = True

    while run:
        screen.fill((0, 0, 0))

        # event handlers
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                exit_all()

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP] and y_pos > vel:
            y_pos -= vel
            movingSound.play()

        if keys[pygame.K_DOWN] and y_pos < screen_height - rocket.rect.height - vel:
            y_pos += vel
            movingSound.play()

        if keys[pygame.K_ESCAPE]:
            run = False

        # screen.blit() - draws the image on the screen
        screen.blit(bg, (i, 0))
        screen.blit(bg, (screen_width + i, 0))
        if i == -screen_width:
            screen.blit(bg, (screen_width + i, 0))
            i = 0
        i -= 1

        # lives, level
        lives_num = font.render(f"Lives: {lives}", True, (255, 255, 255))
        score_num = font.render(f"Score: {score}", True, (255, 255, 255))
        screen.blit(lives_num, (10, 700))
        screen.blit(score_num, (screen_width - score_num.get_width() - 10, 700))

        rocket.set_position(x_pos, y_pos)

        all_sprites.update()
        all_sprites.draw(screen)

        pygame.display.flip()
        pygame.display.update()

        # collision
        csprite = pygame.sprite.spritecollideany(rocket, asteroids)  # gets which asteroid collides with rocket
        if csprite is not None:
            blast = pygame.image.load("Images/blast_nobg.png")
            blast = pygame.transform.scale(blast, (235, 150))
            blast.set_colorkey((255, 255, 255))
            screen.blit(blast, (x_pos - (rocket.get_width()/2) + 7, rocket.get_y() - (rocket.get_height()/2)))
            pygame.display.flip()
            csprite.rect.x = screen_width
            lives = lives - 1
            hitSound.play()
            time.sleep(0.5)
            gameOver.play()
            time.sleep(2.7)

        if lives == 0:
            for entity in all_sprites:
                entity.kill()
            run = False

        if (score % 20) == 0 and (tscore != score):
            tscore = score
            for ast in asteroids.sprites():
                ast.set_speed(ast.get_speed() + 2)

        clock.tick(fps)


def instructions():
    menu_run = True

    screen.blit(menu_bg,(0,0))

    draw_text('Instructions', font, (255, 255, 255), screen, 20, 20)
    # need different text objects as position is different
    text_1 = smallfont.render('Evade asteroids as you fly through a dangerous',True, (255, 255, 255))
    text_2 = smallfont.render('asteroid field. Be aware of different speeds of',True, (255, 255, 255))
    text_3 = smallfont.render('the asteroids. Enjoy the immersive sound effects', True, (255, 255, 255))
    text_4 = smallfont.render('as you steer away from danger.', True, (255, 255, 255))
    text_5 = smallfont.render('Press the up arrow key to move up,', True, (255, 255, 255))
    text_6 = smallfont.render('down arrow key to move down.', True, (255, 255, 255))
    text_7 = smallfont.render('Click escape to go back to the main menu.', True, (255, 255, 255))
    screen.blit(text_1, (20, 100))
    screen.blit(text_2, (20, 150))
    screen.blit(text_3, (20, 200))
    screen.blit(text_4, (20, 250))
    screen.blit(text_5, (20, 300))
    screen.blit(text_6, (20, 350))
    screen.blit(text_7, (20, 400))

    while menu_run:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    menu_run = False

        pygame.display.update()
        mainClock.tick(fps)


def extra_info():
    running = True

    screen.blit(menu_bg,(0,0))

    draw_text('Extra Information', font, (255, 255, 255), screen, 20, 20)

    text_1 = smallfont.render('* An asteroid is a relatively small, inactive, rocky', True, (255, 255, 255))
    text_2 = smallfont.render('  body orbiting the Sun.', True, (255, 255, 255))
    text_3 = smallfont.render('* The Asteroid Belt between Mars and Jupiter is', True, (255, 255, 255))
    text_4 = smallfont.render('  believed to be a planet that was broken up', True, (255, 255, 255))
    text_5 = smallfont.render('  billions of years ago.', True, (255, 255, 255))
    text_6 = smallfont.render('* Asteroids can also have their own moons!', True, (255, 255, 255))
    text_7 = smallfont.render('* Asteroid Vesta is one of the few asteroids', True, (255, 255, 255))
    text_8 = smallfont.render('  known to have a crust, mantle and core.', True, (255, 255, 255))
    text_9 = smallfont.render('* Eros was the first asteroid on which', True, (255, 255, 255))
    text_10 = smallfont.render('  a spacecraft landed.', True, (255, 255, 255))

    screen.blit(text_1, (20, 100))
    screen.blit(text_2, (20, 150))
    screen.blit(text_3, (20, 200))
    screen.blit(text_4, (20, 250))
    screen.blit(text_5, (20, 300))
    screen.blit(text_6, (20, 350))
    screen.blit(text_7, (20, 400))
    screen.blit(text_8, (20, 450))
    screen.blit(text_9, (20, 500))
    screen.blit(text_10, (20, 550))

    while running:

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False

        pygame.display.update()
        mainClock.tick(fps)


def credits():
    running = True

    screen.blit(menu_bg,(0,0))

    draw_text('Credits', font, (255, 255, 255), screen, 20, 20)
    text_1 = smallfont.render('Created by:', True, (255, 255, 255))
    text_2 = smallfont.render('Avani', True, (255, 255, 255))
    text_3 = smallfont.render('Prachita', True, (255, 255, 255))
    text_4 = smallfont.render('Nithila', True, (255, 255, 255))
    screen.blit(text_1, (290, 250))
    screen.blit(text_2, (325, 300))
    screen.blit(text_3, (325, 350))
    screen.blit(text_4, (325, 400))
    pygame.display.update()

    while running:
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()

            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    running = False

        mainClock.tick(fps)


def endGame(score):
    end_run = True
    ret = False

    screen.fill((0, 0, 0))
    end_img = pygame.image.load("Images/GameOver.jpg")
    end_img = pygame.transform.scale(end_img,(screen_width,screen_height))
    screen.blit(end_img,(0,0))

    replay_text = smallfont.render('Replay', True, (255, 255, 255))
    replay = pygame.Rect(275, 565, 200, 50)
    go_back_text = smallfont.render('Press escape to go back to the main menu', True, (255, 255, 255))
    score_num = font.render(f"Score: {score}", True, (255, 255, 255))

    pygame.draw.rect(screen, (255, 0, 0), replay)
    screen.blit(replay_text, (322, 565))
    screen.blit(go_back_text, (75, 610))
    screen.blit(score_num,(285,505))

    while end_run:

        for event in pygame.event.get():
            if event.type == QUIT:
                end_run = False
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    end_run = False

            if event.type == MOUSEBUTTONDOWN:
                if event.button == 1:
                    mouse_x, mouse_y = pygame.mouse.get_pos()
                    if replay.collidepoint((mouse_x, mouse_y)):
                        ret = True
                        end_run = False

        pygame.display.update()
        mainClock.tick(fps)

    return ret


def exit_all():
    pygame.quit()
    quit()

run = True
state = 0

Titlescreen()
while run:
    if state == 0: # main menu - 0
        clicked = main_menu()
        if clicked == 1: # start game button
            state = 1
        elif clicked == 2: # instructions button
            instructions()
        elif clicked == 3: # extra info button
            extra_info()
        elif clicked == 4: # credits button
            credits()
        elif clicked == 5 or clicked == 0: # exit button
            run = False
    elif state == 1: # game - 1
        game()
        state = 2
    elif state == 2: #endGame - 2
        replay = endGame(score)
        if replay:
            state = 1
        else:
            state = 0

pygame.quit()
